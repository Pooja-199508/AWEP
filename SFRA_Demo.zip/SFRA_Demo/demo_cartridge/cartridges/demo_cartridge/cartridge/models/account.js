'use strict',

 var base=module.superModule;

function getProfile(profile) {

   var result;

   if (profile) {
       result = {
           firstName: profile.firstName,
           lastName: profile.lastName,
           dob: profile.dob,
           gender: profile.gender,
           email: profile.email,
           phone: Object.prototype.hasOwnProperty.call(profile, 'phone') ? profile.phone : profile.phoneHome,
           password: '********'
       };
   } else {
       result = null;
   }
   return result;
}
 module.exports = function account(currentCustomer, addressModel, orderModel) {
    base.call(this, currentCustomer, addressModel, orderModel);
    this.profile = getProfile(currentCustomer.raw.profile);

};