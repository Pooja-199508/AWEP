
'use strict';

var base = module.superModule;
module.exports = function fullProduct(product, apiProduct, options) {
    base.call(this, product, apiProduct, options);


    Object.defineProperty(product, 'color', {
        enumerable: true,
        value: apiProduct.custom.color
    });

    return product;

};

