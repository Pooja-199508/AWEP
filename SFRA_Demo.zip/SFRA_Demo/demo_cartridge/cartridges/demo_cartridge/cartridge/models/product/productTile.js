'use strict';

var base = module.superModule;
module.exports = base;