const mainComments = document.querySelectorAll('.comment_container')
const commentReplies = document.querySelectorAll('.comment_container-reply')
let comments = []
const word = (text) => {
    const splitedString = text.split(' ');
    const marked = document.createElement('span');
    const paragraph = document.createElement('p');
    const restString = document.createTextNode(splitedString.slice(1).join(' '))
    marked.classList.add('blue')
    marked.innerHTML = `${splitedString[0]} `
    paragraph.append(marked)
    paragraph.append(restString)
    return paragraph
  }

const plusValue = (elem) => {
    elem.closest('.counter').querySelector('.counter_value').innerHTML =
    Number.parseInt(elem.closest('.counter').querySelector('.counter_value').innerHTML) + 1
  }
const minusValue = (elem) => {
  elem.closest('.counter').querySelector('.counter_value').innerHTML =
  Number.parseInt(elem.closest('.counter').querySelector('.counter_value').innerHTML) - 1
}

const getData = async () => {
  return await fetch('./data.json')
  .then(async (response) => {
    try {
      const data = await response.json();
      const comment = JSON.parse(localStorage.getItem('comments')) || [];
      const merged = data.comments.concat(comment);
      data.comments = merged;
      console.log(merged);
      return data;
    } catch (error) {
      console.log(error);
    }
  });
}
  getData().then(data => {
    for(let i = 0; i <= data.comments.length-1; i++){
      console.log(data.comments[i])
      mainComments[i].querySelector('.user_name a').textContent = data.comments[i].user.username
      mainComments[i].querySelector('.comment_text').textContent = data.comments[i].content
      mainComments[i].querySelector('.counter_value').textContent = data.comments[i].score
      mainComments[i].querySelector('.user_avatar img').src = data.comments[i].user.image.webp
      mainComments[i].querySelector('.user_time').textContent = data.comments[i].createdAt
      if(data.comments[i].replies.length > 0){
        for(let c = 0; c <= data.comments[i].replies.length-1; c++){
            console.log(data.comments[i].replies[c])
            commentReplies[c].querySelector('.comment_text').innerHTML = `<span class="blue">@${data.comments[i].replies[c].replyingTo}</span> ${data.comments[i].replies[c].content}`;
            commentReplies[c].querySelector('.counter_value').textContent = data.comments[i].replies[c].score
            commentReplies[c].querySelector('.user_avatar img').src = data.comments[i].replies[c].user.image.webp
            commentReplies[c].querySelector('.user_name a').textContent = data.comments[i].replies[c].user.username
            commentReplies[c].querySelector('.user_time').textContent = data.comments[i].replies[c].createdAt
        }
      }
  }
})

//send comment
  const sendComment = (src, username) => {
    const div = document.createElement('div')
    div.classList.add('comment_container')
    div.classList.add('current_user')
    const text = document.querySelector('.comment_input').value
    const currentComm = `
    <div class="comment_card">
      <div class="comment_counter counter">
        <div class="counter_plus">
        <img src="./images/icon-plus.svg" alt="plus">
        </div>
        <div class="counter_value">0</div>
        <div class="counter_minus">
          <img src="./images/icon-minus.svg" alt="minus">
          </div>
      </div>
      <div class="comment_main">
        <div class="comment_header header">
          <div class="header_user user">
            <div class="user_avatar">
              <img src="${src}" alt="avatar">
            </div>
            <div class="user_name"><a href="#" class="id">${username}</a></div>
            <div class="user_marker">you</div>
            <div class="user_time">1 minutes ago</div>
          </div>
          <div class="user_action">
            <div class="header_delete"><img src="./images/icon-delete.svg" alt="Reply"> Delete</div>
            <div class="header_update"><img src="./images/icon-edit.svg" alt="Reply"> Edit</div>
          </div>
        </div>
        <div class="comment_text">
          ${text}
        </div>
      </div>
    </div>`
    if(text !== ''){
     div.innerHTML = currentComm
     comments.push(div)
     // save comment to local storage
     const comment = {
      user:{ username,
      image:{webp:src}},
      content: text,
      score: 0,
      replies: [],
      createdAt: new Date().toLocaleString()
    }
    console.log(comment);
    const storedComments = JSON.parse(localStorage.getItem('comments')) || []
    storedComments.push(comment)
    localStorage.setItem('comments', JSON.stringify(storedComments))
    }
     return div
    }

getData().then(data => {
  document.querySelector('.comment_send').onclick = () => {
    if( data.currentUser.username != undefined){
      document.querySelector('main').append(sendComment(data.currentUser.image.webp, data.currentUser.username))
      document.querySelector('.comment_input').value = ''
   }
  }
  let comments = JSON.parse(localStorage.getItem('comments')) || [];
   //delete
   document.querySelector('main').addEventListener('click', (elem) => {
    if(elem.target.classList.contains('header_delete')){
      document.querySelector('.popup').style.display = "flex"
      document.querySelector("body").style.overflowY = "hidden"
      document.querySelector('.popup').style.marginTop = window.pageYOffset + "px"
      document.querySelector('.popup_cancel').onclick = () => {
      document.querySelector('.popup').style.display = "none"
      document.querySelector("body").style.overflowY = "auto"
      }

      document.querySelector('.popup_delete').onclick = () => {
      elem.target.closest('.current_user').parentNode.removeChild(elem.target.closest('.current_user'));
      // Remove the comment from the local storage
      comments = comments.filter(comment => comment.id !== elem.target.dataset.id); //Remove comment from the comments array
      localStorage.setItem('comments', JSON.stringify(comments)); // Save comments to local storage
      document.querySelector('.popup').style.display = "none"
      document.querySelector("body").style.overflowY = "auto"
      }
    }

    //reply
    else if(elem.target.classList.contains('header_reply')){
      const replyBlock = document.createElement('div')
      replyBlock.classList.add('comment_container')
      replyBlock.classList.add('comment_container-reply')
      replyBlock.classList.add('add')
      replyBlock.innerHTML = `
      <div class="add_container">
        <div class="add_avatar">
          <img src="./images/avatars/image-juliusomo.webp" alt="">
        </div>
        <textarea type="text" placeholder="Add a comment..." class="comment_input">@${elem.target.closest('.comment_container').querySelector('.user_name a').textContent}</textarea>
        <button class="comment_send">Reply</button>
      </div>`
      elem.target.closest('.comment_container').append(replyBlock)
      elem.target.closest('.comment_container').querySelector('.comment_input')

      elem.target.closest('.comment_container').querySelector('.comment_send').onclick = () => {
        const reply = sendComment(data.currentUser.image.webp, data.currentUser.username)
        const text = reply.querySelector('.comment_text').textContent.trim()
        reply.querySelector('.comment_text').textContent = ''
        reply.classList.add('comment_container-reply')
        reply.querySelector('.comment_text').append(word(text))
        elem.target.closest('.comment_container').append(reply)
        comment.push(reply)
        localStorage.setItem('comments', JSON.stringify(comments)) // Save comments to local storage
        elem.target.closest('.comment_container').removeChild(replyBlock)
      }
    }
    //update
    else if(elem.target.classList.contains('header_update')){
      const updText = elem.target.closest('.comment_container').querySelector('.comment_text')
      const textArea = document.createElement('textarea')
      textArea.value = updText.textContent.trim()
      textArea.classList.add('comment_input')
      const updBtn = document.createElement('button')
      updBtn.textContent = 'Edit'
      updBtn.classList.add("comment_send")
      updBtn.style.alignSelf = "flex-end"
      elem.target.closest('.comment_main').removeChild(updText)
      elem.target.closest('.comment_main').append(textArea)
      elem.target.closest('.comment_main').append(updBtn)
      updBtn.onclick = () => {
          updText.textContent = ''
          updText.append(word(textArea.value))
          elem.target.closest('.comment_main').append(updText)
          elem.target.closest('.comment_main').removeChild(textArea)
          elem.target.closest('.comment_main').removeChild(updBtn)
          // Find the comment in the comments array
        const comment = comments.find(comment => comment.id === elem.target.dataset.id);
        // Update the comment text
        comment.comment = textArea.value;
        // Update the comment in the local storage
        localStorage.setItem('comments', JSON.stringify(comments));
      }
    }
    else if(elem.target.getAttribute('alt') === 'plus'){
      plusValue(elem.target)
    }
    else if(elem.target.getAttribute('alt') === 'minus'){
      minusValue(elem.target)
    }
 })
})
